#include <stm32f407xx.h>

void configure()	// Configure function for pins configuration
{
	RCC->AHB1ENR |= 0x9;	// Enable clocks of bit 0 and bit 3 
	int pin_A = 0;
	GPIOA->MODER &= ~(0x3<<(pin_A*2));	// PA0 logic 00
	int pin_D = 13;
	GPIOA->MODER &= ~(0x3<<(pin_D*2));	// PD13 logic 00 for Input
	GPIOD->MODER |= (0x1<<(pin_D*2));	// PD13 logic 01 for Output
}

int main()
{
	configure();	// Calling configure function
	
	int pin = 13;	// Pin 13 for PD13 of Orange LED
	
	while (1)
	{
		if (GPIOA->IDR&0x1)	// If button is pressed
		{
			GPIOD->ODR |= (0x1<<pin);	// Turns ON LED
		}
		else
		{
			GPIOD->ODR &= ~(0x1<<pin);	// Turns OFF LED
		}
	}
}
