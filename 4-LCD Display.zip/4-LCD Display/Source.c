#include<stm32f4xx.h>

void configure(void)
{
	RCC->AHB1ENR |=0x8;			// CLK Enable Port D
	RCC->AHB1ENR |=0x10;  		// CLK Enable Port E
	
	for(int pin=0; pin<=7; pin++)		// Output Logic 01 for PD 0-7
	{
		GPIOD->MODER &= ~(0x3<<(pin*2));
		GPIOD->MODER |= (0x01<<(pin*2));      
	}
	for(int pin=1; pin<=3; pin++)		// Output Logic 01 of PE 1-3
	{
		GPIOE->MODER &= ~(0x3<<(pin*2));
		GPIOE->MODER |= (0x01<<(pin*2));      
	}
}

void delay_us(uint32_t x)	// Microsecond Delay Function
{
  volatile unsigned int i;
  volatile unsigned int j;
  for (i=0; i<x; i++)
  {
    j = 11;
    while (j != 0)
    {
      j--;
    }
  }
}

void delay_ms(uint32_t x)	// Millisecond Delay Function
{
  volatile unsigned int i;
  for (i=0; i<x; i++)
  {
    delay_us(1000);
  }
}

void LCD_Write_Com(unsigned char command)		// Function for Writing Commands
{
	GPIOE->ODR &= ~(0x2);		// PE1 -> RS logic 0 because Command Instruction
	GPIOE->ODR &= ~(0x4);   	// PE2 -> RW logic 0 
	GPIOE->ODR |= (0x8);  		// PE3 -> Enable logic 1
	delay_us(2);
	GPIOD->ODR &= ~(0xFF);		// PD 0-7 clears bits
	GPIOD->ODR |= command;		// Command transfer on PD 0-7
	delay_us(2);
	GPIOE->ODR &= ~(0x8);		// Enable logic 0
	delay_us(2);
}

void LCD_Write_Data(unsigned char data)
{
	GPIOE->ODR |= (0x2);  		// PE1 -> RS logic 1 because Data
	GPIOE->ODR &= ~(0x4);     	// PE2 -> RW logic 0
	GPIOE->ODR |= (0x8);  	  	// PE3 -> Enable logic 1
	delay_us(2);
	GPIOD->ODR &= ~(0xFF);		// PD 0-7 clears bits
	GPIOD->ODR |= data;			// Data transfer on PD 0-7
	delay_us(2);
	GPIOE->ODR &= ~(0x8);		// Enable logic 0
	delay_us(2);
}

void LCD_Initialization()
{
	LCD_Write_Com(0x38);		// Function Set
	LCD_Write_Com(0x0C);  		// Display ON - Cursor OFF
	LCD_Write_Com(0x06); 		// Cursor Shift to Right
	LCD_Write_Com(0x01);  		// Clear Display
	LCD_Write_Com(0x80);		// Home location of Cursor
}

int main()
{
	configure();
	LCD_Initialization();
 
	unsigned char A[16] = {'=', '=', 'H', 'E', 'L', 'L', 'O', ' ', ' ', 'W', 'O', 'R', 'L', 'D', '=', '='};

	for (volatile int i=0; i<16; i++)
	{
		delay_ms(2);	
		LCD_Write_Data(A[i]);				// Printing data on LCD
	}
	while (1)		// Infinite Loop
	{}
	return 0;
}
