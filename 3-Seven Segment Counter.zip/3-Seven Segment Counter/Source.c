#include <stm32f407xx.h>

unsigned char A[10] = {0x3F, 0x6, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F};	// Array for Hex values of Digits 0-9

void configure()	// Configure function for pins configuration
{
	RCC->AHB1ENR |= 0x1;	// Enable clock of bit 0 for PA pins
	int pin;
	for (pin=1; pin<8; pin++)	// Loop for Output configurations of PA1-7 pins
	{
		GPIOA->MODER &= ~(0x3<<(pin*2));	// PA1-7 logic 00 for Input
		GPIOA->MODER |= (0x1<<(pin*2));		// PA1-7 logic 01 for Output
	}
}

void delay_us(uint32_t x)	// Microsecond Delay Function
{
  volatile unsigned int i;
  volatile unsigned int j;
  for (i=0; i<x; i++)
  {
    j = 11;
    while (j != 0)
    {
      j--;
    }
  }
}

void delay_ms(uint32_t x)	// Millisecond Delay Function
{
  volatile unsigned int i;
  for (i=0; i<x; i++)
  {
    delay_us(1000);
  }
}

int main()
{
	configure();	// Configure function calling
	
	int loop = 0;	// Loop counter for showing Digits 0-9
	
	while (1)
	{
		GPIOA->ODR &= ~(0xFF<<1);	// Clears bits 1-8 of ODR Register
		
		GPIOA->ODR |= (A[loop++]<<1);	// Sets bits for showing Digits 0-9 on 7-Segment LED
		
		delay_ms(125);		// Delay of almost 1 second for clear changing of Digits
		
		if (loop>=10)		// If loop counter is >= 10, restarts loop counter
		{
			loop = 0;
		}
	}
}
