#include <stm32f407xx.h>

unsigned int mask(int);	// Function for MASK creation
void configure(void);	// Function for PINS configuration

void delay_us(uint32_t x)	// Microsecond Delay Function
{
  volatile unsigned int i;
  volatile unsigned int j;
  for (i=0; i<x; i++)
  {
    t = 11;
    while (t != 0)
    {
      t--;
    }
  }
}

void delay_ms(uint32_t x)	// Millisecond Delay Function
{
  volatile unsigned int i;
  for (i=0; i<x; i++)
  {
    delay_us(1000);
  }
}

int main(void)
{
	configure();	// Configure function calling
	
	int flag = 0;	// flag for button status
	int led = 0;	// led for LED status
	
	while (1)
	{
		delay_ms(5);	// Delay of 5 ms
		
		if ((GPIOA->IDR&0x1) && flag == 0)	// If button is pressed and previous flag was 0
		{
			delay_ms(5);	// Delay for noise/bouncing of button
			if (GPIOA->IDR&0x1)	// Again checking button status after delay of 5 ms
			{
				flag = 1;	// Button state changes
				if (led==0)
					led = 1;	// Turns ON LED
				else
					led = 0;
			}
		}
		else
			flag = 0;	// Button is not pressed
		
		if (led==1)
			GPIOD->ODR |= mask(13);		// Turning ON LED
		else if (led==0)
			GPIOD->ODR &= ~mask(13);	// Turning OFF LED
	}
}

unsigned int mask(int pin)	// Function returning mask of pin
{
	return 0x1<<pin;
}

void configure()
{
	RCC->AHB1ENR |= 0x9;			// Enable clock for AHB1 pins
	GPIOA->MODER = Input(0); 		// bit 0 for PA0		  
	GPIOD->MODER =  Output(13);		// bit 13 for PD13
}

int Input(int pin)		// Logic 00 of MODER
{
	return GPIOA->MODER &= ~(0x3<<(pin*2));			//Clears bit 0 and bit 1 of MODER[0]
}

int Output(int pin)		// Logic 01 of MODER
{
	GPIOD->MODER &= ~(0x3<<(pin*2));						//Clears bit 12 and bit 13 of MODER[6]
	return GPIOD->MODER |= (0x1<<(pin*2));			//Sets bit 13 of MODER[6]
}
